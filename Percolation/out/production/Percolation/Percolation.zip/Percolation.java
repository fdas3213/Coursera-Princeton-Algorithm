import edu.princeton.cs.algs4.WeightedQuickUnionUF;

// create n-by-n grid, with all sites blocked
public class Percolation {
    private WeightedQuickUnionUF id;
    private boolean openSites[];
    private int gridSize;
    private final int topIndex;
    private final int bottomIndex;
    private static int numOpenSites = 0;

    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException();
        }
        gridSize = n;
        topIndex = 0;
        bottomIndex = n*n+1;
        id = new WeightedQuickUnionUF(n * n + 2);
        openSites = new boolean[n * n + 2];
        openSites[topIndex] = true;
        openSites[bottomIndex] = true;
    }

    private int getIndex(int i, int j){
        if (i < 1 || i > this.gridSize || j < 1 || j > this.gridSize) {
            throw new IllegalArgumentException("Index out of bounds");
        }
        return (i-1) * gridSize + j;
    }

    // open site (row, col) if it is not open already
    public void open(int row, int col){
        if (row < 1 || row > this.gridSize || col < 1 || col > this.gridSize){
            throw new IllegalArgumentException("Index out of bounds");
        }
        int index = getIndex(row,col);
        openSites[index] = true;
        numOpenSites++;

        //if firstrow or last row, connect to fake top and bottom
        if (row == 1) id.union(index, topIndex);
        if (row == gridSize) id.union(index, bottomIndex);
        //west
        if (col > 1 && isOpen(row, col - 1)){
            id.union(index, (row * (col - 1) + 1));
        }
        //east
        if (col < gridSize && isOpen(row, col + 1)) {
            id.union(index, (row * (col + 1) + 1));
        }
        //south
        if (row > 1 && isOpen(row-1, col)){
            id.union(index, ((row-1)*col + 1));
        }
        //north
        if (row < gridSize && isOpen(row + 1, col)){
            id.union(index, ((row + 1) * col + 1));
        }

    }

    public boolean isOpen(int row, int col){
        return openSites[getIndex(row, col)];
    }

    public int numberOfOpenSites(){
        return numOpenSites;
    }

    public boolean percolates(){
        return id.connected(topIndex, bottomIndex);
    }

    public boolean isFull(int row, int col){
        if (row > 1 && row <= gridSize && col > 1 && col <= gridSize){
            return id.connected(topIndex, getIndex(row,col));
        }else{
            throw new IllegalArgumentException();
        }
    }

}
